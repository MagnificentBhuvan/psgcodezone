var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/mydb";
var express = require('express');
var bodyParser = require('body-parser');
var app     = express();
var mysql = require('mysql');
var compiler = require('compilex');
var ObjectId = require('mongodb').ObjectID;
app.set('view engine', 'ejs');
//Note that in version 4 of express, express.bodyParser() was
//deprecated in favor of a separate 'body-parser' module.
app.use(bodyParser.urlencoded({ extended: true })); 

MongoClient.connect(url, function(err, db) 
{
     if (err) throw err;
app.get('/',function(req,res)
{
 dbo = db.db("mydb");
dbo.collection("question").find({},{q_desc:0}).toArray(function(err, result) {
  if (err) throw err;
  console.log("Successful");
  console.log(result[1].q_name);
  db.close();
  res.render('pages/index_O', {
    result: result
});

});

});
});
MongoClient.connect(url, function(err, db) 
{
     if (err) throw err;
app.get('/ques_tab',function(req,res)
{
    dbo = db.db("mydb");
    dbo.collection("question").find({},{q_desc:0}).toArray(function(err, result) {
        if (err) throw err;
        // console.log("Successful");
        // console.log(result[1].q_name);
         db.close();
        res.render('pages/question_tabs', {
          result: result
      });
});
});
});
app.get('/ques_tab_css',function(req,res)
{
    res.sendFile(__dirname+'/ques_tab_css/style.css');
});
app.get('/s',function(req,res)
{
  res.sendfile( __dirname + "/home.html");

}
);
app.get('/login',function(req,res)
{
  res.sendfile( __dirname + "/indexaws.html");

}
);

app.get('/amazon1' ,function(req,res)
{
  console.log('hai');  
    res.sendfile(__dirname+'/amazon-cognito/amazon-cognito-userpool_org.js');
});
app.get('/amazon2' ,function(req,res)
{
    console.log('hai1');
    res.sendfile(__dirname+'/amazon-cognito/amazon-cognito-identity.js');
});
app.get('/amazon3' ,function(req,res)
{
    console.log('hai2');
    res.sendfile(__dirname+'/amazon-cognito/jquery.min.js');
});
app.get('/admin1',function(req,res)
{
res.sendfile(__dirname+'/creating_challenge.html');
});

MongoClient.connect(url, function(err, db) 
{
     if (err) throw err;
app.get('/Index_O',function(req,res)
{
    dbo = db.db("mydb");
    ques_id=ObjectId(req.query['q_id']);
    console.log(ques_id);
    console.log('visited');
    dbo.collection("question").findOne({_id:ques_id}, function(err, result) {
        if (err) throw err;
        console.log(result);
        db.close();
      
    
    res.render('pages/index_O', {
        result:result  
    });
});
});
});
MongoClient.connect(url, function(err, db) 
{
     if (err) throw err;
app.post('/serv',function(req,res)
{
  var q_name=req.body.qname;
  var q_desc=req.body.desc ;
  var q_const=req.body.qconst;
  var q_inp=req.body.qinp;
  var q_oup=req.body.qoup;
  dbo = db.db("mydb");
var myobj={q_name:q_name,q_desc:q_desc,q_const:q_const,q_inp:q_inp,q_oup:q_oup}

dbo.collection("question").insertOne(myobj,function(err, res) {
  if (err) throw err;
  console.log("Inserted");
  db.close();
});
});

});
app.get('/admin_view_css',function(req,res)
{
    res.sendFile(__dirname +'/adminview/admin_view.css')
});
app.get('/Indexcss',function(req,res)
{
  res.sendfile( __dirname + "/Index/index.css");

}
);
app.get('/pgms',function(req,res)
{
  res.sendfile( __dirname + "/pgms.html");

}
);
app.get('/IndexO_css',function(req,res)
{
    
  res.sendfile( __dirname + "/Index_O/index_o.css");

}


);
app.get("/js1",function(req,res)
{
    res.sendFile(__dirname + "/js1/index.js");
}

);
app.get("/css1",function(req,res)
{
    res.sendFile(__dirname + "/css1/style.css");
}

);
app.get('/login',function(req,res)
{
  res.sendfile( __dirname + "/index.html");

}
);
app.get('/out',function(req,res)
{
    res.sendfile( __dirname + "/Images/output1.jpg");
}
);
app.get('/image',function(req,res)
{
    res.sendfile( __dirname + "/Images/img1.jpg");
}
);
app.get('/challenge_img',function(req,res)
{
    res.sendfile( __dirname + "/Images/challenge.jpg");
}
);
app.get('/imageq',function(req,res)
{
    res.sendfile( __dirname + "/Images/ques_Tabs1.jpg");
}
);

app.post('/server' , function (req , res ) {

    console.log("server visited");
    console.log(req.params.obj);
    res.sendfile( __dirname + "/index_O.html");
});

//app.use(express.bodyParser());

app.post('/logininsert', function(req, res) {
 // res.send('You sent the name "' + req.body.first_name + '". "' + req.body.last_name + '" .  "' + req.body.signupemail + '" . "' + req.body.signuppassword + '"');

  con.connect(function(err) {
    if (err) throw err;
    console.log("Connected!");
    var sql = "INSERT INTO logindetails (FirstName, LastName, Email, Password) VALUES ('"+req.body.first_name+"', '"+req.body.last_name+"', '"+req.body.signupemail+"','"+req.body.signuppassword+"')";
    con.query(sql, function (err, result) {
      if (err) throw err;

      console.log('Successfully Signed Up');
      console.log("1 record inserted");
     
      // res.writeHead(200,{contenttype:"text/html"})
     // res.redirect('http://localhost:8080/index_O.html');
     // res.end(); 
   //   res.redirect('https://www.google.com/');
   //res.setHeader("text/html");
   //res.redirect('http://localhost:8080/index_O.html');
    });
  });
 
});
app.get('/Home' , function (req , res ) {

	res.sendfile( __dirname + "/index_O.html");

});

app.post('/signup', function(req, res,next) {
  
//  res.send('You sent the name "' + req.body.signinemail + '"."' + req.body.signinpassword + '"."');
  
  con.connect(function(err) {
    if (err) throw err;
    con.query("SELECT Password FROM logindetails WHERE Email = '"+req.body.signinemail+"'", function (err, result) {
      console.log(result[0].Password);
      if (err) throw err;
      if(result[0].Password == req.body.signinpassword) 
      {
          console.log('Successfully signed in');
        	
        console.log("Successfully Logged in");
    //res.sendFile( __dirname + "/index_O.html");
      
        var server=require('./server.js');
        app.use('/server',server); 
        
        res.redirect('/server');
        
      // res.end();
     
      }
      else
      {
          res.sendFile("Invalid Username Or Password");
          
          //res.end();
      }

    });
  });
  

});

/*-------------------------------------------------------------------------------------*/
app.post('/compilecode' , function (req , res ) {
    
	var code = req.body.code;	
	var input = req.body.input;
    var inputRadio = req.body.inputRadio;
    var lang = req.body.lang;
    if((lang === "C") || (lang === "C++"))
    {        
        if(inputRadio === "true")
        {    
        	var envData = { OS : "windows" , cmd : "g++"};	   	
        	compiler.compileCPPWithInput(envData , code ,input , function (data) {
        		if(data.error)
        		{
        			res.send(data.error);    		
        		}
        		else
        		{
        			res.send(data.output);
        		}
        	});
	    }
	   else
	   {
	   	
	   	var envData = { OS : "windows" , cmd : "g++"};	   
        	compiler.compileCPP(envData , code , function (data) {
        	if(data.error)
        	{
        		res.send(data.error);
        	}    	
        	else
        	{
        		res.send(data.output);
        	}
    
            });
	   }
    }
    if(lang === "Java")
    {
        if(inputRadio === "true")
        {
            var envData = { OS : "windows" };     
            console.log(code);
            compiler.compileJavaWithInput( envData , code , function(data){
                res.send(data);
            });
        }
        else
        {
            var envData = { OS : "windows" };     
            console.log(code);
            compiler.compileJavaWithInput( envData , code , input ,  function(data){
                res.send(data);
            });

        }

    }
    if( lang === "Python")
    {
        if(inputRadio === "true")
        {
            var envData = { OS : "windows"};
            compiler.compilePythonWithInput(envData , code , input , function(data){
                res.send(data);
            });            
        }
        else
        {
            var envData = { OS : "windows"};
            compiler.compilePython(envData , code , function(data){
                console.log("enbvdata"+envData);
                res.render('pages/ouput', {
                    result1:data  
                });
            });
        }
    }
    if( lang === "CS")
    {
        if(inputRadio === "true")
        {
            var envData = { OS : "windows"};
            compiler.compileCSWithInput(envData , code , input , function(data){
                res.send(data);
            });            
        }
        else
        {
            var envData = { OS : "windows"};
            compiler.compileCS(envData , code , function(data){
                res.send(data);
            });
        }

    }
    if( lang === "VB")
    {
        if(inputRadio === "true")
        {
            var envData = { OS : "windows"};
            compiler.compileVBWithInput(envData , code , input , function(data){
                res.send(data);
            });            
        }
        else
        {
            var envData = { OS : "windows"};
            compiler.compileVB(envData , code , function(data){
                res.send(data);
            });
        }

    }

});

app.get('/fullStat' , function(req , res ){
    compiler.fullStat(function(data){
        res.send(data);
    });
});
/*----------------------------------------------------------------------------------------*/


app.listen('8000');
app.listen(8080, function() {
  console.log('Server running at http://127.0.0.1:8080/');
});