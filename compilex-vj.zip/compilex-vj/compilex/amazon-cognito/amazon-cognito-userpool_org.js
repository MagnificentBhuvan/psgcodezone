AWS.config.region = 'us-east-1'; // Region
AWS.config.credentials = new AWS.CognitoIdentityCredentials({
    IdentityPoolId: 'us-east-1:171ac83d-e24e-4dc9-a1bb-d0beebbff5e8',
});
var poolData = {
    // UserPoolId : 'us-east-1_BdLpq38uM', // your user pool id here
    // ClientId : '59l00klb2kd1si3vhc78kh0aul' // your app client id here
    UserPoolId : 'us-east-1_6WSSr8fIf', // your user pool id here
    ClientId : '145v9q0tdm7smdcj4q6tc2gn1n' // your app client id here
};

var userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);
var cognitoUser;

            function sendOTP()
            {
              if((document.getElementById("otp").value === null) || document.getElementById("otp").value === "")
               console.log("Confirmation code is Null");
              else
              {
               console.log(document.getElementById("otp").value);
              // console.log(document.getElementById("validationCustomEmail").value);
               var userData = {
                    Username : document.getElementById("validationCustomEmail").value,
                    Pool : userPool
                };
                var cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);
                cognitoUser.confirmRegistration(document.getElementById("otp").value, true, function(err, result) {
                    if (err) {
                        swal("Error", err.message || JSON.stringify(err), "error");
                        //alert(err.message || JSON.stringify(err));
                        return;
                    }
                    swal("Success", "Registration Successful", "success");
                    //alert("Your Account is Confirmed");
                    $('#myModal').modal('hide');
                    console.log('call result: ' + result);
                    setTimeout(function(){ window.location.replace('/Index_O'); }, 3000); 
                });
              }
            }
    function resendOTP()
    {
        cognitoUser.resendConfirmationCode(function(err, result) {
            if (err) {
                swal("Error", err.message || JSON.stringify(err), "error");
                //alert(err.message || JSON.stringify(err));
                return;
            }
            console.log('call result: ' + result);
        });
    }

    function validate_student(){
        
          // Fetch all the forms we want to apply custom Bootstrap validation styles to
          var forms = document.getElementsByClassName('needs-validation');
          // Loop over them and prevent submission
          var validation = Array.prototype.filter.call(forms, function(form) {
            
                
            if (form.checkValidity() === true) { 
                
                $('#loadingmodal').modal('show');
           
    var nameofuser = {
        Name : 'name',
        Value : document.getElementById("validationCustomName").value
    };
    // var dateofbirth = {
    //     Name : 'birthdate',
    //     Value : document.getElementById("validationCustomdob").value
    // };
    var phoneno = {
        Name : 'phone_number',
        Value : document.getElementById("countrycode").value+document.getElementById("validationCustomPhoneno").value
    };

    var email = {
        Name : 'email',
        Value : document.getElementById("validationCustomEmail").value
    };

    var attributeList = [];
    var attributename = new AmazonCognitoIdentity.CognitoUserAttribute(nameofuser);
    var attributeEmail = new AmazonCognitoIdentity.CognitoUserAttribute(email);
    var attributephone = new AmazonCognitoIdentity.CognitoUserAttribute(phoneno);
    attributeList.push(attributename);
    attributeList.push(attributeEmail);
    attributeList.push(attributephone);

    
    userPool.signUp(document.getElementById('validationCustomEmail').value, document.getElementById("validationCustomPassword").value, attributeList, null, function(err, result){
        $('#loadingmodal').modal('hide');
        
        if (err) {
            swal("Error", err.message || JSON.stringify(err), "error");
            //alert(err.message || JSON.stringify(err));
            
            return;
        }
        cognitoUser = result.user;
        $('#loadingmodal').modal('hide');
        $('#myModal').modal('show');
        console.log('user name is ' + cognitoUser.getUsername());
    });
    event.preventDefault();
    event.stopPropagation();

    // $('#myModal').modal('show');
            }
            else
            {
                // $('#myModal').modal('show');
                event.preventDefault();
                event.stopPropagation();

            }
              form.classList.add('was-validated');
            }, false);          
        }


        
    function validate_alumni(){
  
        // Fetch all the forms we want to apply custom Bootstrap validation styles to
        var forms1 = document.getElementsByClassName('needs-validation1');
        // Loop over them and prevent submission
        var validation1 = Array.prototype.filter.call(forms1, function(form) {
          
              
            if (form.checkValidity() === true ) { 
                $('#loadingmodal').modal('show');

                var authenticationData = {
                    Username : document.getElementById("validationCustomEmailalumni").value,
                    Password : document.getElementById("validationCustomPasswordalumni").value,
                };
                var authenticationDetails = new AmazonCognitoIdentity.AuthenticationDetails(authenticationData);
                var poolData = {
                    UserPoolId : 'us-east-1_6WSSr8fIf', // your user pool id here
                    ClientId : '145v9q0tdm7smdcj4q6tc2gn1n' // your app client id here
                };
                var userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);
                var userData = {
                    Username : document.getElementById("validationCustomEmailalumni").value,
                    Pool : userPool
                };
                var cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);
                cognitoUser.authenticateUser(authenticationDetails, {
                    onSuccess: function (result) {
                        $('#loadingmodal').modal('hide');
                        var accessToken = result.getAccessToken().getJwtToken();
                        
                        //POTENTIAL: Region needs to be set if not already set previously elsewhere.
                        AWS.config.region = 'us-east-1';
            
                        AWS.config.credentials = new AWS.CognitoIdentityCredentials({
                            IdentityPoolId : 'us-east-1:171ac83d-e24e-4dc9-a1bb-d0beebbff5e8', // your identity pool id here
                            Logins : {
                                // Change the key below according to the specific region your user pool is in.
                                'cognito-idp.us-east-1.amazonaws.com/us-east-1_6WSSr8fIf' : result.getIdToken().getJwtToken()
                            }
                        });
                        cognitoUser = userPool.getCurrentUser();
                        if (cognitoUser != null) {
                            cognitoUser.getSession(function(err, session) {
                                if (err) {
                                    swal("Error",err,"Error");
                                   //alert(err);
                                    return;
                                }
                                console.log('session validity: ' + session.isValid());
                                cognitoUser.getUserAttributes(function(err, result) {
                                    if (err) {
                                        swal("Error",err,"Error");
                                        //alert(err);
                                        return;
                                    }
                                    else
                                    {
                                        //alert(result);
                                       
                                    }
                          
                                });
                                AWS.config.credentials = new AWS.CognitoIdentityCredentials({
                                    IdentityPoolId : 'us-east-1:171ac83d-e24e-4dc9-a1bb-d0beebbff5e8', // your identity pool id here
                                    Logins : {
                                        // Change the key below according to the specific region your user pool is in.
                                        'cognito-idp.us-east-1.amazonaws.com/us-east-1_6WSSr8fIf' : session.getIdToken().getJwtToken()
                                    }
                                });
                    
                                // Instantiate aws sdk service objects now that the credentials have been updated.
                                // example: var s3 = new AWS.S3();
                    
                            });
                        }
                        //refreshes credentials using AWS.CognitoIdentity.getCredentialsForIdentity()
                        AWS.config.credentials.refresh((error) => {
                            if (error) {
                                 console.error(error);
                            } else {
                                 // Instantiate aws sdk service objects now that the credentials have been updated.
                                 // example: var s3 = new AWS.S3();
    
                                 console.log('Successfully logged!');
                                 
                                 swal("Success", "Login Successful", "success");
                                 setTimeout(function(){ window.location.replace('/Index_O'); }, 3000); 
                            }
                        });
                       // window.location('/Index_O');
                    },
            
                    onFailure: function(err) {
                        alert(err.message || JSON.stringify(err));
                    },
            
                });
                
            }
            else
            {
                
                // $('#myModal').modal('show');
                event.preventDefault();
                event.stopPropagation();

            }
            form.classList.add('was-validated');
          }, false);          
      
   
    }