import java.util.*;

class Main{
Scanner in=new Scanner(System.in);
public static void main(String ar[])
{
//int a=in.nextInt();
//int b=in.nextInt();
//System.out.println(a+b);
System.out.println("Hello");
}
}