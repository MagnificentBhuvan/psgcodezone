import java.util.*;
class Main
{
Scanner in=new Scanner(System.in);
public static void main(String args[])
{
int a=in.nextInt();
System.out.println(a);
System.out.println("Hellow");
}
}