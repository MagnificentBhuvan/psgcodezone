import java.io.*;
class Main
{
public static void main(String sar[])
{
System.out.println("Hello");
}
}
