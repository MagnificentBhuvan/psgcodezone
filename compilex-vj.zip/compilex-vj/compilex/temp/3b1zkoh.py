a=input();
print(a)