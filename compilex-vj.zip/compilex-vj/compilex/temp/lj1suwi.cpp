#include<iostream>
using namespace std;
int main()
{
cout<<"Hello Wolrd";
return 0;
}
