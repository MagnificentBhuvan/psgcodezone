#include<iostream>
using namespace std;
int main()
{
    cout<<"Heera";
    return 0;
}