print("t")
print("at")