#include<iostream>
using namespace std;
int main()
{
cout<<"Ajay Bhadhran";
return 0;
}
